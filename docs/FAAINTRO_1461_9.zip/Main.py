# -*- coding: utf-8 -*-
"""
Created on Sun Oct 01 20:23:59 2017

@author: profesores faa
"""

from Datos import Datos

#dataset=Datos('f:/temp/german.data')
#dataset=Datos('f:/temp/tic-tac-toe.data')
dataset=Datos('ConjuntosDatos/balloons.data')
print(dataset.datos)
